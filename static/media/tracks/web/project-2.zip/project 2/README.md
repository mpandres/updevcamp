export MINITWIT_SETTINGS env var or edit minitwit.py

python3 -m flask -a csitwit initdb
python3 csitwit.py

This is a modification of the MiniTwit example from Flask.
